package com.github.backend.meta.controller;

import com.github.backend.meta.entity.Meta;
import com.github.backend.meta.service.MetaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/meta")
public class MetaController {
    
    @Autowired
    public MetaDataService metaService;

    @GetMapping
    public ResponseEntity<?> getMeta() {
        List<Meta> list = metaService.getMeta();
        return ResponseEntity.ok(list);
    }
    @PutMapping
    public ResponseEntity<?> changeMeta(@RequestBody List<String> list) {
        return ResponseEntity.ok(list);
    }
}