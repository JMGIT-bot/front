package com.github.backend.meta.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "meta")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Meta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String key;

    @Column(nullable = false)
    private String value;
}