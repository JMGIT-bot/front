package com.github.backend.meta.repository;

public class MetaRepository {
    
}
