// postcss.config.js
module.exports = {
    css: ["@/assets/tailwind.css"], // Tailwind CSS 경로 추가
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
};
