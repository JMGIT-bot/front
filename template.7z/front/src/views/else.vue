<template>
    <div>
        <h2 class="text-2xl font-bold">ELSE Page</h2>
        <p>This is the ELSE Page!</p>
    </div>
</template>
