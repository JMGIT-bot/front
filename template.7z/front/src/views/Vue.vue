<template>
    <div>
        <h2 class="text-2xl font-bold">VUE Page</h2>
        <p>This is the VUE Page!</p>
    </div>
</template>
