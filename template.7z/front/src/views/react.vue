<template>
    <div>
        <h2 class="text-2xl font-bold">REACT Page</h2>
        <p>This is the REACT Page!</p>
    </div>
</template>
