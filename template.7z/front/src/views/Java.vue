<template>
    <div>
        <h2 class="text-2xl font-bold">JAVA Page</h2>
        <p>This is the JAVA Page!</p>
    </div>
</template>
